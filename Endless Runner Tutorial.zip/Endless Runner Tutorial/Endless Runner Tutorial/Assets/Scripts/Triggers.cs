﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Triggers : MonoBehaviour {

	public Transform teleportNode;


	//When something enters the trigger
	void OnTriggerEnter(Collider other){

		//		Debug.Log (other.name);
//		Debug.Log (other.tag);

		if (other.tag == "Player") {
			Debug.Log ("Happy to see you");
			other.transform.position = teleportNode.position;
			other.transform.rotation = teleportNode.rotation;
		}
	}

	void OnDrawGizmos(){
		Gizmos.color = Color.yellow;
		Gizmos.DrawLine (transform.position, teleportNode.position);
//		Gizmos.DrawCube (Vector3.zero, new Vector3 (3, 4, 5));

	
	}
//	//When something exits the trigger
//	void OnTriggerExit(){
//		Debug.Log ("Sorry to see you go");
//	}
//
//	//When something stays within the trigger
//	void OnTriggerStay(){
//		Debug.Log ("I wish you would leave");
//	}
}

