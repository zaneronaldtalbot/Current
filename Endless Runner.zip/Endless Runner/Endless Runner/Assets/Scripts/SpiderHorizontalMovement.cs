﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpiderHorizontalMovement : MonoBehaviour {
// Assigning a random speed to each spider's movement
	private float randomSpeed;
// Outlines the minimum speed the spider can travel at
	public float minSpeed;
// Outlines the maximum speed the spider can travel at
	public float maxSpeed;
// ----------------------------------------------------------------------------
	void FixedUpdate(){
// Assigns each spawned spider a speed from a random range of between 1 and 5
		randomSpeed = Random.Range (1f, 5f);
	}

}
