﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KillZone : MonoBehaviour {

	public GameObject killZone;

	void OnCollisionEnter (Collision other){
		if (other.gameObject.tag == "KillWall")
			Destroy (this.gameObject);
	}
}
