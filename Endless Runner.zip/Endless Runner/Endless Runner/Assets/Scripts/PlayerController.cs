﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using XboxCtrlrInput;

public class PlayerController : MonoBehaviour {

// A rigidbody to give the player movement through physics simulation
	public Rigidbody rb;
// The start speed at which the player will move forward along the Z axis
	public float speed = 3;
// The button to let the player reset after death
	public Button resetButton;

//--------------------------------------------------------------------------
	void MoveForward (){
// Calls on the prompt to push the player along the Z axis	
		pushForward ();
	}
//--------------------------------------------------------------------------
// Use this for initialization
	void Start () {
// Getting the object's rigid body		
		rb = GetComponent<Rigidbody> ();
	}
//--------------------------------------------------------------------------
	void Update (){
// Calls on the prompt to push the player along the Z axis		
		pushForward ();
// Press 'Space' to reload the level
		if (Input.GetKeyDown (KeyCode.Space))
			SceneManager.LoadScene ("Main");
// Press 'Start' on the Xbox Controller to reload the level
		if (XboxCtrlrInput.XCI.GetButtonDown(XboxCtrlrInput.XboxButton.Start))
			SceneManager.LoadScene ("Main");
			
	}
// Telling the player that if they collide with anything labelled 'lethal'
// the objects speed will decrease to zero and they will have the option to
// restart the level
	void OnCollisionEnter (Collision other){
		if (other.gameObject.tag == "lethal") {
			resetButton.gameObject.SetActive (true);
			speed = 0;
			Debug.Log ("Ouch");
		}
	}
//--------------------------------------------------------------------------
// Tells the reset button to load the scene titled 'Main' on click		
	public void ResetButton (){
		SceneManager.LoadScene ("Main");
	}
//--------------------------------------------------------------------------
// Pushes the player forward along the Z axis
	private void pushForward (){
		transform.position += transform.forward * speed * Time.deltaTime;
	}
//--------------------------------------------------------------------------
	private void FixedUpdate(){
// Giving the player movement along the horizontal and vertical axes
		float moveHorizontal = Input.GetAxis ("Horizontal");
		float moveVertical = Input.GetAxis ("Vertical");
// Outlines how the player will move
		Vector3 movement = new Vector3 (moveHorizontal, moveVertical, 0);
// Adding force to player movement 
		rb.AddForce (movement * speed);

	}
}
