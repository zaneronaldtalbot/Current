﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour {


	public Rigidbody rb;
	public float speed = 5;

	public Button resetButton;


	void MoveForward (){
		transform.position += transform.forward * speed * Time.deltaTime;

	}
	// Use this for initialization
	void Start () {
		rb = GetComponent<Rigidbody> ();

	}
	
	void Update (){
		transform.position += transform.forward * speed * Time.deltaTime;

	}
	void OnCollisionEnter (Collision other){
		if (other.gameObject.tag == "lethal") {
			resetButton.gameObject.SetActive (true);
		
		}

	}

	public void ResetButton (){
		SceneManager.LoadScene ("Main");

	}

	private void FixedUpdate(){
		float moveHorizontal = Input.GetAxis ("Horizontal");
		float moveVertical = Input.GetAxis ("Vertical");

		Vector3 movement = new Vector3 (moveHorizontal, moveVertical, 0);

		rb.AddForce (movement * speed);

	}
}
