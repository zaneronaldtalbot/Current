﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpiderVerticalMovement : MonoBehaviour {

	public Transform spider;
	private float randomSpeed;
	public float minSpeed;
	public float maxSpeed;

	void Start(){
		randomSpeed = Random.Range (1f, 5f);
	}

	// Update is called once per frame
	void Update () {

		spider.transform.localPosition = new Vector3(0,Mathf.PingPong (randomSpeed * Time.time,2) ,0);
	

	}
}