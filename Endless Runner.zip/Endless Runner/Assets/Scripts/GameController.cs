﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameController : MonoBehaviour {


	public List<GameObject> groundPieceList = new List<GameObject> ();


	//A counter of all the pieces we have spwaned
	public int groundPieceCounter = 0;
	//Depth of each ground piece
	public int depthOfGroundPiece = 2;
	//How many pieces we want to spawn
	public int numberOfGroundPiece = 40;

	public float playerPositionCounter = 0;
	public GameObject player;

	void Update (){
		if (player.transform.position.z > playerPositionCounter){
			playerPositionCounter += depthOfGroundPiece;

			BuildLevel ();
		}
	}

	private void BuildLevel(){
		GameObject groundPieceToPlace = null;

		groundPieceToPlace = groundPieceList [Random.Range (0, groundPieceList.Count)];

		Instantiate (groundPieceToPlace, Vector3.forward * groundPieceCounter * depthOfGroundPiece, Quaternion.identity);
		groundPieceCounter++;
	}

	// Use this for initialization
	void Start () {

		for (int i = 0; i < numberOfGroundPiece; i++) {

			BuildLevel ();
		}
	}

}
