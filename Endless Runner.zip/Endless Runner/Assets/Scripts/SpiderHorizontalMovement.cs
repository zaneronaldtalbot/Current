﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpiderHorizontalMovement : MonoBehaviour {

	private float randomSpeed;
	public float minSpeed;
	public float maxSpeed;

	void FixedUpdate(){
		//animation["HorizontalSpider"].speed = randomSpeed;
		randomSpeed = Random.Range (1f, 5f);
	}

}
