﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using XboxCtrlrInput;

public class TitleScreen : MonoBehaviour {
// --------------------------------------------------------------------------------------------
//Update ()
// Runs every frame
// 
// Param:
//			None
// Return:
//			Void
// --------------------------------------------------------------------------------------------
	void Update (){
// Allows the player to use the start button on the xbox controller to start the game 
		if (XboxCtrlrInput.XCI.GetButtonDown(XboxCtrlrInput.XboxButton.Start)){
			SceneManager.LoadScene ("Main");
		Time.timeScale = 1;
	}
		if (XboxCtrlrInput.XCI.GetButtonDown(XboxCtrlrInput.XboxButton.Y)){
			SceneManager.LoadScene ("Controls");
	}
		if (XboxCtrlrInput.XCI.GetButtonDown(XboxCtrlrInput.XboxButton.Back)){
			Application.Quit ();
		}
}
// --------------------------------------------------------------------------------------------
//StartButton ()
// Tells the button to load the scene titled 'Main' on click
// 
// Param:
//			None
// Return:
//			Void
// --------------------------------------------------------------------------------------------
	public void StartButton (){
		SceneManager.LoadScene ("Main");
	}
}