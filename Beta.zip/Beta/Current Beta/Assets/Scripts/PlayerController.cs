﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using XboxCtrlrInput;

public class PlayerController : MonoBehaviour {

// A rigidbody to give the player movement through physics simulation
	public Rigidbody rb;
// The start speed at which the player will move forward along the Z axis
	public float speed = 3;
// The button to let the player reset after death
	public Button resetButton;
// Telling our game controller to reference the Score script
	private Score ScoreManager;
// Declaring how fast we want the flurry speed to be
	public float flurrySpeed = 10;
// The speed the player will travel after releasing flurry
	public float flurryExit = 10;
// The maximum speed the player can flurry at
	public float maxSpeed = 100;
// --------------------------------------------------------------------------------------------
//MoveForward ()
// The function that pushes the player forward along the Z axis
// 
// Param:
//			None
// Return:
//			Void
// --------------------------------------------------------------------------------------------
	void MoveForward (){
// Calls on the prompt to push the player along the Z axis	
		PushForward ();
	}
// --------------------------------------------------------------------------------------------
//Start ()
// Runs during initialisation
// 
// Param:
//			None
// Return:
//			Void
// --------------------------------------------------------------------------------------------
	void Start () {
// Getting the object's rigid body		
		rb = GetComponent<Rigidbody> ();
// Telling our script to get the components of the Score Script
		ScoreManager = FindObjectOfType<Score> ();
	}
// --------------------------------------------------------------------------------------------
//Update ()
// Runs every frame
// 
// Param:
//			None
// Return:
//			Void
// --------------------------------------------------------------------------------------------
	void Update (){
// Calls on the prompt to push the player along the Z axis		
		PushForward ();
// Press 'Space' to reload the level
		if (Input.GetKeyDown (KeyCode.Space)) {
			SceneManager.LoadScene ("Main");
		}
// Press 'Start' on the Xbox Controller to reload the level
		if (XboxCtrlrInput.XCI.GetButtonDown (XboxCtrlrInput.XboxButton.Back)) {
			SceneManager.LoadScene ("Main");
		}
// Hold A to 'flurry' - travel at a faster rate
		if (XboxCtrlrInput.XCI.GetButton (XboxCtrlrInput.XboxButton.A)){
			rb.AddForce (transform.forward * flurrySpeed);
		}
// Release A to travel at a slower rate
		if (XboxCtrlrInput.XCI.GetButtonUp (XboxCtrlrInput.XboxButton.A)){
			rb.velocity = rb.velocity / flurryExit;
		}
// If the player's speed is greater than the max speed
// Make the player's speed equal to the max speed 
		if (speed >= maxSpeed){
			speed = maxSpeed;
		}
	}
// --------------------------------------------------------------------------------------------
//OnCollisionEnter ()
// Runs every frame
// 
// Param:
//			Collision other - the collision of any other objects that collide with this trigger
// Return:
//			Void
// --------------------------------------------------------------------------------------------
	void OnCollisionEnter (Collision other){
// Telling the player that if they collide with anything labelled 'lethal'
// the objects speed will decrease to zero and they will have the option to
// restart the level
		if (other.gameObject.tag == "lethal") {
			resetButton.gameObject.SetActive (true);
			Time.timeScale = 0;
// stops the score from increasing after collision
			ScoreManager.scoreIncreasing = false;
		}
	}
// --------------------------------------------------------------------------------------------
//ResetButton ()
// Tells the reset button to load the scene titled 'Main' on click
// 
// Param:
//			None
// Return:
//			Void
// --------------------------------------------------------------------------------------------
	public void ResetButton (){
		SceneManager.LoadScene ("Main");
		Time.timeScale = 1;
	}
// --------------------------------------------------------------------------------------------
//PushForward ()
// Pushes the player forward along the Z axis
// 
// Param:
//			None
// Return:
//			Void
// --------------------------------------------------------------------------------------------
	private void PushForward (){
		transform.position += transform.forward * speed * Time.deltaTime;
	}
// --------------------------------------------------------------------------------------------
//FixedUpdate ()
// Runs every fixed framerate frame - used because we're adding force to the movement
// 
// Param:
//			None
// Return:
//			Void
// --------------------------------------------------------------------------------------------
	private void FixedUpdate(){
// Giving the player movement along the horizontal and vertical axes
		float moveHorizontal = Input.GetAxis ("Horizontal");
		float moveVertical = Input.GetAxis ("Vertical");
// Outlines how the player will move
		Vector3 movement = new Vector3 (moveHorizontal / 3f, moveVertical, 0);
// Adding force to player movement 
		rb.AddForce (movement * speed);

	}
}