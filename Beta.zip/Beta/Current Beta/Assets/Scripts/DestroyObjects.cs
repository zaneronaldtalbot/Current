﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyObjects : MonoBehaviour {
// --------------------------------------------------------------------------------------------
//Die ()
// Destroying Objects in the level after a certain time has elapsed
// 
// Param:
//			None
// Return:
//			Void
// --------------------------------------------------------------------------------------------
	void Die(){
// Destroy an object in the level		
		Destroy (gameObject);
	}
// --------------------------------------------------------------------------------------------
//Update ()
// Called once per frame
// 
// Param:
//			None
// Return:
//			Void
// --------------------------------------------------------------------------------------------
	void Update(){
// Waiting 30 seconds to start destroying objects		
		Invoke ("Die", 30f);
	}
}
