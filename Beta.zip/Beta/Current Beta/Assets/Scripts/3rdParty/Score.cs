﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Score : MonoBehaviour {

	public Text scoreText;

	public float scoreCount;

	public float pointsPerSecond;

	public bool scoreIncreasing;

	void Update(){
		
		if (scoreIncreasing){
			scoreCount += pointsPerSecond * Time.deltaTime;
		}
		scoreText.text = "Score: " + Mathf.Round(scoreCount);

		if (XboxCtrlrInput.XCI.GetButton (XboxCtrlrInput.XboxButton.A)){
			scoreCount += scoreCount * 0.01f;
		}
	}		
}
