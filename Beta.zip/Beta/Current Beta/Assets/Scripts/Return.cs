﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using XboxCtrlrInput;

public class Return : MonoBehaviour {
// --------------------------------------------------------------------------------------------
//Update ()
// Called once per frame
// 
// Param:
//			None
// Return:
//			Void
// --------------------------------------------------------------------------------------------
	void Update () {
// If the player presses B [in 'controls' scene] they will return to the title screen 		
		if (XboxCtrlrInput.XCI.GetButtonDown(XboxCtrlrInput.XboxButton.B)){
			SceneManager.LoadScene ("TitleScreen");
		}
	}
}
