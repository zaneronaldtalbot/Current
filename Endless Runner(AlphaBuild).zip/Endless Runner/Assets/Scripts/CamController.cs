﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CamController : MonoBehaviour {
// Defining the object that the camera will classify as the player -- also the object to follow
	public GameObject player;
// Stores the distance between the player and the camera
	private Vector3 offset;
// --------------------------------------------------------------------------------------------
	// Use this for initialization
	void Start () {
// Saves the offset value between the player and the camera		
		offset = transform.position - player.transform.position;
	}
// --------------------------------------------------------------------------------------------
	// Late Update is called after Update on each frame
	void LateUpdate () {
// Moves the camera forward with the player, but keeps it at the original offset distance 
// that it calculated at Start
		transform.position = player.transform.position + offset;
	}
}