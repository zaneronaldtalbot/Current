﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XboxCtrlrInput;
using UnityEngine.SceneManagement;

public class PauseGame : MonoBehaviour {

	public Transform canvas;
// ----------------------------------------------------------------------------------------------------------------------
	// Update is called once per frame
	void Update () {
// If the start button on the Xbox controller is pressed then we want to open up the start menu
// We also want to freeze time so that nothing moves
		if (XboxCtrlrInput.XCI.GetButtonDown(XboxCtrlrInput.XboxButton.Start)){

		if (canvas.gameObject.activeInHierarchy == false){
			canvas.gameObject.SetActive  (true);
				Time.timeScale = 0;
		} else{
// When start is pressed again it turns off the pause menu and 
// resets time back to 1, allowing play to continue
			canvas.gameObject.SetActive (false);
				Time.timeScale = 1;
			}
				
		}
// If the menu is up and 'A' is pressed, the game will resume
		if (XboxCtrlrInput.XCI.GetButtonDown(XboxCtrlrInput.XboxButton.A) && canvas.gameObject.activeInHierarchy == true){
			canvas.gameObject.SetActive (false);
			Time.timeScale = 1;
		}
// If the menu is up and 'B' is pressed, it will start the level from the beginning
		if (XboxCtrlrInput.XCI.GetButtonDown(XboxCtrlrInput.XboxButton.B) && canvas.gameObject.activeInHierarchy == true){
			SceneManager.LoadScene ("Main");
			canvas.gameObject.SetActive (false);
			Time.timeScale = 1;
		}
// If the menu is up and 'Y' is pressed, the game will exit to the title screen
		if (XboxCtrlrInput.XCI.GetButtonDown(XboxCtrlrInput.XboxButton.Y) && canvas.gameObject.activeInHierarchy == true){
			SceneManager.LoadScene ("TitleScreen");
		}
	}
}
