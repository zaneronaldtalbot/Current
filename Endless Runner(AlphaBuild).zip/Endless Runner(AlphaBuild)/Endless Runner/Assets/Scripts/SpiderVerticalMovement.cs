﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpiderVerticalMovement : MonoBehaviour {
// Allows us to specify 'spider' in the inspector
	public Transform spider;
// Assigning a random speed to each spider's movement
	private float randomSpeed;
// Outlines the minimum speed the spider can travel at
	public float minSpeed;
// Outlines the maximum speed the spider can travel at
	public float maxSpeed;
// --------------------------------------------------------------------------------------------
//Start ()
// Runs during initialisation
// 
// Param:
//			None
// Return:
//			Void
// --------------------------------------------------------------------------------------------
	void Start(){
// Assigns each spawned spider a speed from a random range of between 1 and 5		
		randomSpeed = Random.Range (1f, 5f);
	}
// --------------------------------------------------------------------------------------------
//Update ()
// Runs every frame
// 
// Param:
//			None
// Return:
//			Void
// --------------------------------------------------------------------------------------------
	void Update () {
// Ping Pong makes the spider travel back and forth on a set path,
// in this scenario along the Y axis at a random speed
		spider.transform.localPosition = new Vector3(0,Mathf.PingPong (randomSpeed * Time.time,2) ,0);
	}
}