﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using XboxCtrlrInput;

public class TitleScreen : MonoBehaviour {
// Allows the player to use the start button on the xbox controller to start the game 
	void Update (){
		if (XboxCtrlrInput.XCI.GetButtonDown(XboxCtrlrInput.XboxButton.Start))
			SceneManager.LoadScene ("Main");
		Time.timeScale = 1;
	}
// -----------------------------------------------------------------------------
// Tells the button to load the scene titled 'Main' on click
	public void StartButton (){
		SceneManager.LoadScene ("Main");
	}

}