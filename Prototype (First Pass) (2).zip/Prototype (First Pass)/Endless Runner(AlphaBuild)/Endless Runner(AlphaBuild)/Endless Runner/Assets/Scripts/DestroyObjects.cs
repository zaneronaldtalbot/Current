﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyObjects : MonoBehaviour {

	void Die(){
		Destroy (gameObject);
	}

	void Update(){
		Invoke ("Die", 30f);
	}
}
