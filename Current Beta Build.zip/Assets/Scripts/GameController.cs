﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameController : MonoBehaviour {

// Sets up a list to put the prefabs into
	public List<GameObject> groundPieceList = new List<GameObject> ();
// A counter of all the pieces we have spwaned
	public int groundPieceCounter = 0;
// Depth of each ground piece
	public int depthOfGroundPiece = 2;
// How many pieces we want to spawn
	public int numberOfGroundPiece = 40;
// Where the player is
	public float playerPositionCounter = 0;
// Outlining what we want to classify as the 'player'
	public GameObject player;
//  The object we want all the spawned prefabs to fall under
	public Transform prefabParent;
// --------------------------------------------------------------------------------------------
//Update ()
// Runs every frame
// 
// Param:
//			None
// Return:
//			Void
// --------------------------------------------------------------------------------------------
	void Update (){
// 	If the player is a certain point into the level we want to spawn more prefabs
		if (player.transform.position.z > playerPositionCounter){
			playerPositionCounter += depthOfGroundPiece;
// Calls upon the function that lets us generate the level
			BuildLevel ();
		}
	}
// --------------------------------------------------------------------------------------------
//BuildLevel ()
// Continuously generates the level from a list of allocated prefabs and places them in the scene
// 
// Param:
//			None
// Return:
//			Void
// --------------------------------------------------------------------------------------------
	private void BuildLevel(){
		GameObject groundPieceToPlace = null;
// Specifying to pull the ground pieces from the public list we set up earlier
		groundPieceToPlace = groundPieceList [Random.Range (0, groundPieceList.Count)];
// Telling the program where and how far forward to place the next ground piece
		GameObject test = Instantiate (groundPieceToPlace, Vector3.forward * groundPieceCounter * depthOfGroundPiece, 
			Quaternion.identity);
		test.transform.SetParent (prefabParent);
		groundPieceCounter++;
	}
// --------------------------------------------------------------------------------------------
//Start ()
// Runs during initialisation
// 
// Param:
//			None
// Return:
//			Void
// --------------------------------------------------------------------------------------------
	void Start () {
		for (int i = 0; i < numberOfGroundPiece; i++) {
// Initiating the build level upon start to make the level instantly fill up with prefabs
			BuildLevel ();

		if (Time.timeScale == 0){
			Time.timeScale = 1;
			}
		}
	}
}